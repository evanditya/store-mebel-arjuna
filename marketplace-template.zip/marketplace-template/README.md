# Marketplace Store Template

Template e-commerce lengkap: Next.js 14 + FastAPI + PostgreSQL.

## Fitur Lengkap
- Katalog produk + varian multi-group (harga & stok per varian)
- Keranjang, checkout, pembayaran Midtrans
- Integrasi pengiriman Biteship (JNE, SiCepat, dll.)
- Ambil di toko: jadwal & info pickup di email + tampilan buyer
- Dashboard seller: produk, pesanan, banner, sub-admin
- Import/export Excel (produk + varian)
- Filter kategori & tab status pesanan di seller dashboard
- Sync stok dari Shopee via Gmail IMAP
- Laporan harian email otomatis 23:00 WIB (PIN-protected /report-harian)
- Super admin + sub-admin dengan permission granular

## Stack
- **Frontend**: Next.js 14, Tailwind CSS, TypeScript (port 5000)
- **Backend**: FastAPI + Python 3.11 (port 8000)
- **Database**: PostgreSQL (SQLAlchemy ORM)
- **Auth**: JWT (python-jose)

## Setup

### 1. Environment variables
```bash
cp .env.example .env
# Edit .env sesuai kebutuhan
```

### 2. Jalankan
```bash
bash start.sh
```
Buka: http://localhost:5000

## Roles
| Role | Akses |
|------|-------|
| `buyer` | Belanja & checkout |
| `seller` | Dashboard penuh (super admin) |
| `admin` | Sub-admin (permission granular) |

## Konfigurasi Toko
Edit `backend/seller_config.json` — atau gunakan halaman Pengaturan di dashboard seller.

## Halaman Tersembunyi
- `/report-harian` — laporan transaksi harian (PIN default: `admin1234`)

## Seed Data
Edit `backend/seed.py` untuk data produk awal.
Model produk lihat di `backend/app/models.py`.
