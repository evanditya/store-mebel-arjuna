"""Seed script — isi dengan data produk Anda."""
from app.database import SessionLocal
from app.models import Product

def seed():
    db = SessionLocal()
    try:
        count = db.query(Product).count()
        if count > 0:
            print(f"Database already has {count} products — skipping seed.")
            return
        print("Database kosong. Tambahkan data produk Anda di sini.")
        # TODO: tambahkan produk Anda
    finally:
        db.close()

if __name__ == "__main__":
    seed()
